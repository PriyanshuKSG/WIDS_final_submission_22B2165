This is a simple artificial Neural Network which is used for basic binary classification.
Batch Gradient Descent and Binary Cross Entropy function is used for Optimization and 
cost function respectively.